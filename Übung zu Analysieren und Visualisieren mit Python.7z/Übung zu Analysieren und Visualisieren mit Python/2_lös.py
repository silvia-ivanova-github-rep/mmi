# -*- coding: utf-8 -*-
# Import von benötigten Modulen:
# codecs: Funktionalität zum Öffnen von Textdateien
# math: Mathematische Funktionen, im Übungsblatt für den Logarithmus
# string: String-Konstanten, Funktionen; im Übungsblatt für die Satzzeichen
import codecs
import math
import string


# Aufgabe 2a)
def get_term_frequency(text):
    # Leeres Dictionary für Wörter und deren Häufigkeit wird erstellt
    term_frequencies = {}
    
    # Text wird vorbereitet: auf Kleinbuchstaben normalisieren und Satzzeichen entfernen
    # Grund: Gleiche Wörter sollen nicht durch Großbuchstaben oder Satzzeichen als verschiedene gespeiochert werden
    text = text.lower()
    for character in string.punctuation:
        text = text.replace(character, " ")
    
    # Aufteilung des Textes in Wörter, die in einer Liste gespeichert sind
    word_list = text.split()
    
    # In einer Schleife wird jedes Wort der Wortliste als Schlüssel in das Dictionary gesteckt
    # Falls es noch nicht existiert erhält das Wort als zugehörigen Wert 1 (erstes Auftreten)
    # Ansonsten wird hochgezählt
    for word in word_list:
        if word not in term_frequencies:
            term_frequencies[word] = 1
        else:
            term_frequencies[word] += 1
    
    # Das fertige Dictionary wird zurückgegeben
    return term_frequencies

    
# Aufgabe 2b)
def calculate_tfidf(term, text, documents):

    # Für das übergebene Wort 'term' wird die Häufigkeit im übergebenen Text erfragt
    # Das Erfragen erfolgt über den Aufruf von get_term_frequency und dem Übergeben von term als Schlüssel
    # get_term_frequency(text)[term] funktioniert, da aus get_term_frequency(text) ein Dictionary zurückgegeben wird
    tf = get_term_frequency(text)[term]
    
    # Eine Zählvariable für die Dokumentenhäufigkeit wird erstellt. Gleich als Float, damit später keine Integer-Division erfolgt
    doc_frequency = 0.0
    
    # Die Korpusgröße (Anzahl der Dokumente) wird vom documents Dictionary erfragt
    corpus_size = len(documents)
    
    # Aus dem documents Dictionary wird durch jeden Schlüssel und seinem zugehörigen Wert (sind jeweils Strings) durchgegangen.
    # Es wird überprüft, ob term in den Texten existiert. Falls ja, wird die Zählvariable hochgezählt, ansonsten passiert nichts.
    for text in documents.values():
        if term in text.lower():
            doc_frequency += 1
    
    # idf - Formel in Python ausgeschrieben; +1 im Nenner, um Division durch 0 zu vermeiden    
    idf = math.log(corpus_size/(1+doc_frequency))
    
    # tf-idf Formel aus dem Übungsblatt
    tfidf = tf*idf
    return tfidf

# Alles unter dieser Zeile ist nicht relevant fuer das Bearbeiten der Aufgaben. Die restlichen Zeilen kuemmern sich um das sofortige Feedback eurer Loesungen.
# Oeffnen der Dokumente und speichern in Strings. Zur Verstaendlichkeit und Vermeidung von Fehlern bei Bearbeitung der Uebungsaufgabe wird jedes Dokument einzeln geladen
# und in einer Variable abgespeichert, bevor sie in ein Dictionary gespeichert werden. (Alternativ kann man eine Schleife ueber den Ordner laufen lassen.)
nlp_doc = codecs.open("nlp.txt", encoding="utf-8").read()
markov_doc = codecs.open("markov_random_field.txt", encoding="utf-8").read()
parsing_doc = codecs.open("parsing.txt", encoding="utf-8").read()
sentiment_doc = codecs.open("sentiment_analysis.txt", encoding="utf-8").read()
wordsense_doc = codecs.open("word-sense_disambiguation.txt", encoding="utf-8").read()

documents = {}
documents["nlp"] = nlp_doc
documents["markov"] = markov_doc
documents["parsing"] = parsing_doc
documents["sentiment"] = sentiment_doc
documents["wordsense"] = wordsense_doc


# Aufruf der Methoden: in term_frequency wird das von get_term_frequency erstellte Dictionary gespeichert (vom Dokument (String) das in documents["nlp"] steckt)
# In tfidf_markov und tfidf_parsing wird der tf-idf-Wert aus calculate_tfidf gespeichert.
# Calculate_tfidf verwendet als Eingabewerte den jeweiligen Term ("markov" bzw. "parsing") und dem Dokument in dem der Term untersucht werden soll.
term_frequency = get_term_frequency(documents["nlp"])
tfidf_markov = calculate_tfidf("markov", documents["nlp"], documents)
tfidf_parsing = calculate_tfidf("parsing", documents["nlp"], documents)


# Hier wird das erwartete Ergebnis mit dem Ergebnis aus euren fertigen Methoden abgeglichen, zum Feedback ueber eine moegliche korrekte Loesung der Aufgaben.
print "2a) Ueberpruefung auf korrektes Dictionary:\n"
test_dict = {u'limited': 1, u'all': 2, u'results': 5, u'existing': 2, u'decisions': 1, u'relationships': 1, u'whose': 1, u'languages': 2, u'to': 14, u'stochastic': 1, u'dramatically': 1, u'advantage': 1, u'very': 2, u'continues': 1, u'startlingly': 1, u'parry': 1, u'tagging': 1, u'entire': 1, u'solved': 1, u'small': 1, u'markov': 1, u'revolution': 1, u'titled': 1, u'ten': 1, u'further': 1, u'implemented': 1, u'what': 1, u'errors': 1, u'eliza': 3, u'experiment': 1, u'focuses': 2, u'answers': 1, u'desired': 1, u'objects': 1, u'focused': 2, u'fulfill': 1, u'constituency': 2, u'depended': 1, u'great': 1, u'chomskyan': 1, u'involved': 1, u'larger': 1, u'amount': 2, u'published': 1, u'tasks': 2, u'plot': 1, u'use': 1, u'from': 3, u'working': 1, u'racter': 1, u'carbonell': 1, u'contains': 1, u'two': 1, u'lessening': 1, u'theoretical': 1, u'more': 6, u'sort': 1, u'parliament': 1, u'started': 1, u'occurred': 1, u'surprisingly': 1, u'qualm': 1, u'valued': 1, u'ibm': 1, u'this': 3, u'work': 2, u'theories': 1, u'can': 2, u'learn': 1, u'making': 1, u'my': 1, u'example': 2, u'history': 1, u'1980s': 3, u'effectively': 1, u'information': 2, u'provide': 1, u'write': 1, u'criterion': 1, u'dominance': 1, u'blocks': 1, u'may': 1, u'turing': 2, u'after': 1, u'produce': 1, u'unfamiliar': 1, u'predicates': 1, u'such': 4, u'law': 1, u'data': 8, u'response': 1, u'types': 1, u'a': 21, u'ambiguous': 1, u'natural': 3, u'perhaps': 1, u'algorithms': 4, u'nonsensical': 1, u'began': 1, u'typical': 2, u'parsing': 7, u'produces': 1, u'developed': 4, u'years': 2, u'produced': 2, u'including': 2, u'statistical': 4, u'linguistics': 2, u'expectations': 1, u'late': 2, u'systems': 10, u'hidden': 1, u'might': 1, u'then': 1, u'non': 2, u'combination': 1, u'1954': 1, u'1950': 1, u'not': 1, u'now': 2, u'worlds': 1, u'grammar': 4, u'fully': 1, u'\ufeffthe': 1, u'found': 2, u'difficult': 1, u'successful': 1, u'successively': 1, u'hard': 1, u'year': 1, u'out': 1, u'canada': 1, u'funding': 1, u'restricted': 2, u'semi': 1, u'research': 6, u'increase': 1, u'integrated': 1, u'achieving': 1, u'earlier': 1, u'schank': 1, u'given': 3, u'free': 1, u'g': 1, u'completely': 1, u'base': 1, u'complicated': 1, u'earliest': 1, u'enormous': 1, u'interaction': 1, u'language': 6, u'english': 1, u'automatic': 1, u'conducted': 1, u'1970s': 1, u'first': 1, u'emotion': 1, u'major': 1, u'features': 1, u'sentence': 3, u'primary': 2, u'long': 1, u'slower': 1, u'little': 1, u'annotated': 4, u'introduction': 1, u'structured': 1, u'system': 2, u'corpus': 1, u'georgetown': 1, u'that': 6, u'alan': 1, u'part': 1, u'authors': 1, u'translation': 7, u'than': 2, u'wide': 1, u'jabberwacky': 1, u'vocabularies': 1, u'were': 6, u'1975': 1, u'result': 2, u'and': 18, u'sam': 1, u'rogerian': 1, u'say': 1, u'have': 1, u'sentences': 2, u'seem': 1, u'1964': 1, u'1966': 2, u'able': 2, u'also': 1, u'potential': 1, u'take': 1, u'which': 8, u'multiple': 2, u'programmers': 1, u'underpinnings': 1, u'multilingual': 1, u'cullingford': 1, u'most': 3, u'weizenbaum': 1, u'probabilistic': 2, u'why': 1, u'especially': 2, u'unsupervised': 1, u'sometimes': 1, u'steady': 1, u'proceedings': 1, u'typically': 1, u'fact': 1, u'laws': 1, u'nlp': 5, u'pcfg': 1, u'specifically': 1, u'based': 2, u'knowledge': 1, u'cache': 1, u'state': 1, u'failed': 1, u'gradual': 1, u'thousands': 1, u'inferior': 1, u'do': 1, u'trees': 1, u'words': 1, u'report': 1, u'during': 2, u'comprising': 1, u'calling': 1, u'common': 1, u'where': 1, u'art': 1, u'intelligence': 2, u'1960s': 1, u'see': 2, u'computer': 1, u'are': 5, u'techniques': 1, u'written': 4, u'between': 2, u'conceptual': 1, u'progress': 1, u'approach': 1, u'available': 1, u'however': 5, u'hurts': 2, u'article': 1, u'both': 1, u'successes': 1, u'many': 6, u's': 1, u'context': 1, u'wilensky': 1, u'among': 1, u'others': 1, u'learning': 7, u'modeling': 1, u'union': 1, u'due': 2, u'been': 3, u'attaching': 1, u'much': 2, u'ontologies': 1, u'corresponding': 1, u'1950s': 1, u'psychotherapist': 1, u'these': 3, u'reliable': 1, u'corpora': 2, u'will': 1, u'margie': 1, u'chatterbots': 1, u'at': 1, u'almost': 1, u'is': 5, u'lehnert': 2, u'parse': 2, u'in': 17, u'claimed': 1, u'if': 1, u'generic': 1, u'things': 2, u'make': 2, u'complex': 1, u'speech': 2, u'units': 1, u'limitation': 1, u'talespin': 1, u'pam': 1, u'european': 1, u'used': 1, u'upon': 1, u'hand': 3, u'flurry': 1, u'transformational': 1, u'discouraged': 1, u'robust': 1, u'recent': 2, u'task': 1, u'1979': 1, u'1978': 2, u'1977': 1, u'1976': 1, u'underlies': 1, u'analysis': 1, u'thought': 1, u'machinery': 1, u'sets': 1, u'the': 42, u'proposed': 1, u'less': 1, u'increasingly': 2, u'generally': 3, u'accurate': 1, u'human': 3, u'using': 3, u'shrdlu': 1, u'web': 1, u'grammatical': 1, u'had': 2, u'governmental': 1, u'input': 4, u'has': 5, u'real': 4, u'subtasks': 1, u'government': 1, u'rules': 3, u'showing': 1, u'possible': 1, u'early': 1, u'five': 1, u'world': 3, u'like': 2, u'success': 1, u'soft': 1, u'reduced': 1, u'methods': 1, u'deal': 1, u'some': 2, u'examples': 2, u'recognition': 1, u'provided': 1, u'for': 11, u'decision': 1, u'machine': 8, u'content': 1, u'be': 4, u'patient': 1, u'power': 1, u'tree': 2, u'processing': 2, u'notable': 1, u'notably': 1, u'although': 1, u'sixty': 1, u'analyses': 1, u'by': 3, u'on': 7, u'about': 1, u'would': 1, u'of': 37, u'meehan': 1, u'simulation': 1, u'dependency': 2, u'supervised': 2, u'introduced': 1, u'or': 3, u'computational': 1, u'alpac': 1, u'into': 5, u'within': 1, u'three': 1, u'determine': 1, u'your': 1, u'often': 2, u'rely': 1, u'1981': 1, u'there': 5, u'textual': 1, u'joseph': 1, u'was': 6, u'head': 2, u'understandable': 1, u'russian': 1, u'with': 4, u'responding': 1, u'official': 1, u'up': 3, u'until': 1, u'problem': 1, u'similar': 1, u'called': 1, u'gone': 1, u'moore': 1, u'computing': 1, u'parses': 1, u'exceeded': 1, u'deep': 1, u'an': 2, u'as': 5, u'periods': 1, u'politics': 1, u'marking': 1, u'no': 1, u'amounts': 1, u'whereas': 1, u'when': 4, u'field': 1, u'other': 2, u'test': 1, u'you': 1, u'models': 6, u'building': 1, u'e': 1, u'weights': 1, u'time': 1, u'starting': 1}
if len(set(term_frequency.items()) & set(test_dict.items())) == len(test_dict):
    print "Das sieht soweit gut aus!\n"
else:
    print "Da fehlt noch was!\n"
	
print "2b) Erwarteter Wert fuer markov: {}, erwarteter Wert fuer parsing: {}".format(0.51, 1.56)
if round(tfidf_markov, 2) == 0.51 and round(tfidf_parsing, 2) == 1.56:
    print "Das sieht soweit gut aus!\n"
else:
    print "Nicht korrekte tfidf-Werte erhalten. markov: {}, parsing: {}".format(tfidf_markov, tfidf_parsing)
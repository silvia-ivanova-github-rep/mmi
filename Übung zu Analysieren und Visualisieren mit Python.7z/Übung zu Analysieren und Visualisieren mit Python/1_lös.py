# Musterloesung Uebungsblatt 1, Python-Tutorium
import codecs

# Entfernen von Zeichen aus dem String (in dokument gespeichert) mit replace(<zu entfernendes Zeichen>, <das ersetzende Zeichen>)
# Ueberlegung: Alles was durch Leerzeichen abgegrenzt ist, ist ein Wort. Mit split() wird ein String an Whitespaces (Leerzeichen, Carriage Returns etc.) aufgetrennt, die so getrennten "Stringbruchstuecke" werden aus der Methode split() als Liste zurueckgegeben und in wort_liste gespeichert.
# Die Anzahl der Woerter ist gleich der Anzahl an Elementen in der Liste (): mit len() erhaelt man die Laenge der Liste und somit die Anzahl der Elemente.
# Die Anzahl muss noch aus der Methode mit return zurueckgegeben werden.
def anzahlDerWoerter(dokument):
    dokument = dokument.replace(",", "")
    dokument = dokument.replace(".", "")
    wort_liste = dokument.split()
    anzahl_woerter = len(wort_liste)
    return anzahl_woerter


# Satzzeichen werden wie oben entfernt.
# Da Gross- und Kleinschreibung nicht beachtet werden sollen: lower() wird auf dokument angewendet (upper() funktioniert auch, hier wird alles zu Grossbuchstaben).
# Wieder wird der lange String in dokument mit split() in Woerter aufgeteilt.
# Mit set() wird aus der Wortliste ein Wort"set" gemacht: Da Sets nur einzigartige Elemente haben koennen, werden ueberzaehlige entfernt.
# Die Anzahl der unterschiedlichen Woerter erhaltet man nun durch die Laenge der Liste, wiederum mit len().
def anzahlUnterschiedlicherWoerter(dokument):
    dokument = dokument.replace(",", "")
    dokument = dokument.replace(".", "")
    dokument = dokument.lower()
    wort_liste = dokument.split()
    unterschiedliche_woerter = set(wort_liste)
    anzahl_unterschiedliche_woerter = len(unterschiedliche_woerter)
    return anzahl_unterschiedliche_woerter

dokument = codecs.open("textmining.txt", encoding="utf-8").read()
anzahlDerWoerter = anzahlDerWoerter(dokument)
anzahlUnterschiedlicherWoerter = anzahlUnterschiedlicherWoerter(dokument)

print "1a) " + str(anzahlDerWoerter)
if anzahlDerWoerter == 97:
	print "Das sieht soweit gut aus!\n"
else:
	print "Da fehlt noch was!\n"
	
print "1b) " + str(anzahlUnterschiedlicherWoerter)
if anzahlUnterschiedlicherWoerter == 72:
	print "Das sieht soweit gut aus!\n"
else:
	print "Da fehlt noch was!\n"
	

	

# -*- coding: utf-8 -*-
import pdb

# Lösungsansätze und Erklärung der auftretenden Fehler

# 1)
# Überprüft, ob ein übergebener Parameter 'c' ist.
'''
def check_if_letter_is_c(text):
    # Ein '=' ist ein Zuweisungsoperator; korrekt ist '==' für den Vergleichsoperator
    if (text = 'c'):
        return True
    else:
        # In Python werden die Wahrheitswerte groß geschrieben.
        # Richtig ist: 'False' anstatt 'false'
        return false

# Kein Fehler an sich, aber unnützer Methodenaufruf: Rückgabewert verpufft.
# Für die Überprüfung der Ausgabe muss z.B. ein print Statement verwendet werden.         
check_if_letter_is_c('a')
'''
# Muster:
'''
def check_if_letter_is_c(text):
    if (text == 'c'):
        return True
    else:
        return False
        
print check_if_letter_is_c('a')
'''


# 2)
# Soll den Mittelwert berechnen.
# Auf den ersten Blick ist kein Fehler zu finden, Ergebnis ist anscheinend auch korrekt.
# Bei Verwendung einer anderen Liste (z.B. [1,2,3,4,5]) wird ein falsches Ergebnis berechnet.
# Wichtig ist also: Wenn etwas überprüft werden soll, alle möglichen Testfälle durchspielen.
# Hier beispielsweise: Leere Liste, Liste mit einem Element, Liste mit ganzer Zahl als Mittelwert, Liste mit Nachkommastelle als Mittelwert
'''     
def calculate_average(number_list):
    avg = 0
    for number in number_list:
        avg += number
    # Bei leerer Liste: Division durch 0
    # Außerdem: falls in der Liste kein Float präsent ist, wird Integerdivision durchgeführt
    print avg/len(number_list)
    
calculate_average([1,2,3,4,5])
'''
#Muster:
'''
def calculate_average(number_list):
    if len(number_list) < 1:
        print 'Die Liste ist leer, kein Mittelwert'
    else:
        avg = 0
        for number in number_list:
            avg += number
        # Bei leerer Liste: Division durch 0
        # Außerdem: falls in der Liste kein Float präsent ist, wird Integerdivision durchgeführt
        print avg/float(len(number_list))
    
calculate_average([1,2,3,4,5])
'''


# 3)
# Soll Element an eine übergebene Liste anhängen. Falls keine Liste übergeben wird, soll eine neue Liste mit dem Element ausgegeben werden.
# Da sonst keine Informationen über den Zweck der Funktion bekannt ist, muss davon ausgegeben werden, dass die Funktion diese neu erstellte Liste nur in die Konsole ausgibt, aber nicht speichert
# Problem: Bei jedem neuen Aufruf ohne übergebene Liste, wird das übergebene Element an eine existierende Liste angehängt, obwohl man eigentlich erwartet jedesmal eine ein-elementige Liste zu sehen.
# Erklärung: Der Python-Interpreter sieht sich die Methodendeklaration genau einmal an, danach nie wieder.
# Der Ausdruck 'liste=[]' wird einmal ausgewertet, ab diesem Zeitpunkt existiert eine leere Liste namens 'liste'. An diese werden bei nachfolgenden Aufrufen die Elemente angehängt, anstatt jedesmal erst eine leere Liste zuzuweisen.
# Dies ist kein Fehler an sich, sondern ein unerwartetes Verhalten, wenn man nicht weiß, wie der Interpreter arbeitet. Dieses Verhalten tritt bei allen Datentypen auf, die mutable sind.
# Kein Problem bei immutables (z.B. Strings), da dort jedesmal ein neues Objekt erstellt wird.
'''
def append_to_list(element, liste=[]):
    liste.append(element)
    print liste
    
append_to_list(1)
append_to_list(2)
append_to_list(3)
'''
# Muster:
'''
# Der Ansatz mit 'None' funktioniert mit allen mutable Typen.
def append_to_list(element, liste=None):
    # Erstelle eine leere Liste im lokalen Scope
    if liste == None:
        liste = []
    liste.append(element)
    print liste
    
append_to_list(1)
append_to_list(2)
append_to_list(3)
'''


# 4)
# Soll alle Vorkommnisse eines übergebenen Elements aus der übergebenen Liste entfernen.
# Fehler: Es werden nicht alle Vorkommnisse entfernt.
# Grund: In der for-Schleife wird durch jedes Element der Liste iteriert, während in derselben Schleife die Liste verändert wird. Intern wird ein Index von 0 bis zum Listenende gezählt. remove() entfernt ein Element, alle nachfolgenden Elemente "rücken nach", da nun ein Index unbesetzt ist. Dadurch können Elemente übersprungen werden, da sie zwar zu entfernen sind, aber nun an einen bereits bearbeiteten Index rücken. Tritt auf, wenn zwei zu entfernende Elemente direkt hintereinanderfolgen, ansonsten ist das ein "stiller" Fehler, den man nicht sofort sieht.
'''
def remove_from_list(liste, element):
    for el in liste:
        if el == element:
            liste.remove(element)

elements = ["test", "test", "kein_test", "kein_test", "kein_test", "kein_test", "kein_test", "test", "kein_test", "kein_test", "test"]
# "Fehler"" beim Methodenaufruf: aus einer leeren Liste soll 'test' entfernt werden.
remove_from_list([], 'test')
'''
# Muster:
'''
# Lösung: Man iteriert nicht über die zu verändernde Liste, sondern über eine Kopie. Damit stellt man sicher, dass alle Elemente in der for-Schleife durchlaufen und überprüft werden.
def remove_from_list(liste, element):
    # Liste kopieren
    liste_kopie = liste[:]
    for el in liste_kopie:
        if el == element:
            liste.remove(element)

elements = ["test", "test", "kein_test", "kein_test", "kein_test", "kein_test", "kein_test", "test", "kein_test", "kein_test", "test"]
remove_from_list(elements, 'test')
# Ausgabe der Liste, um das Ergebnis zu überprüfen
print elements
'''


# 5)
# Soll eine Datei auslesen.
# Problem: open() benötigt einen Dateinamen oder Dateipfad. Ist zwar als 'filepath' übergeben, diese Variable ist aber nirgendwo definiert.
# Mögliche Lösung: um unterschiedliche Dateien auslesen zu können, wird filepath als Parameter definiert.
# Nach dem Statement 'print f.read()' zu schließen, soll der Dateiinhalt ausgegeben werden.
# Problem: open() wird mit einem 'w' Parameter aufgerufen, dass nur das Schreiben ermöglicht.
# Lösung: Aufruf mit 'r'
'''        
def open_file():
    with open(filepath, 'w') as f:
        print f.read()
        
open_file()
'''
# Muster:
'''
def open_file(filepath):
    with open(filepath, 'r') as f:
        print f.read()
# Um die Methode aufrufen zu können, muss jetzt ein  Pfad angegeben werden:        
open_file('test.txt')
'''


# 6)
# Nach den verwendeten Methoden und Variablennamen zu urteilen, soll ein text (vermutlich String) manipuliert werden:
# In Kleinbuchstaben umgewandeln
# Satzzeichen entfernen mit dem Hilfsstring string.punctuation
'''    
def normalize_text(text):
    # text wird auf 5 gesetzt. Berücksichtigt man die Methodendeklaration (eine Variable text wird übergeben), sowie die nachfolgenden Statements, ist dies wohl ein Versehen.
    text = 5
    # Aufruf einer nichtexistierenden String-Methode: richtig ist lower()
    # Außerdem: String ist immutable, kann also nicht wie Listen "in place" verändert werden. Das Ergebnis aus lower() muss gespeichert werden.
    text.low()
    for punct in string.punctuation:
        # Das betreffende Zeichen wird entfernt, jedoch mit einem anderen ersetzt.
        # Außerdem: String ist immutable, kann also nicht wie Listen "in place" verändert werden. Das Ergebnis aus replace() muss gespeichert werden.
        text.replace(punct, 0)
    return text
# Kein valider String übergeben: terminales ' fehlt    
normalize_text('ojaosdolqa:;ad,q12,asd..!)
'''
# Muster:
'''
import string
def normalize_text(text):
    text = text.lower()
    for punct in string.punctuation:
        text = text.replace(punct, '')
    return text
    
print normalize_text('ojaosdolqa:;ad,q12,asd..!')
'''


# 7)
# Soll mit zwei übergebenen Werten einen neuen Wert berechnen. 
'''
def calculate_value(a, b):
    result = 0
    # Tippfehler: i statt l.
    # Als Ergebnis wird also immer 0 zurückgegeben, da result nie verändert wird.
    resuit = a+b*10
    return result
    
calculate_value(1,2)
'''
# Muster:
'''
def calculate_value(a, b):
    result = 0
    result = a+b*10
    return result
    
print calculate_value(1,2)
'''


# 8)
# Soll den "fizzbuzz" Algorithmus implementieren:
# Bei Teilbarkeit durch drei soll 'fizz' ausgegeben werden.
# Bei Teilbarkeit durch fünf soll 'buzz' ausgegeben werden.
# Bei Teilbarkeit durch drei und fünf soll 'fizzbuzz' ausgegeben werden.
# Ansonsten soll die Zahl ausgegeben werden.
# Allgemeiner Fehler:
# Die if-Überprüfungen sind auf der selben Ebene und werden damit in jedem Schleifendurchlauf alle überprüft:
# Für jede Zahl wird Teilbarkeit durch 3, Teilbarkeit durch 5, Teilbarkeit durch 3 und 5 geprüft. Trifft jeder Fall zu, wird auch für jeden Fall etwas ausgegeben. Gewollt ist eine Ausgabe pro Zahl.
# Beispiel: 0 wird für alle überprüften Fälle 'True' ergeben und deshalb in die Konsole 'fizz', 'buzz' und 'fizzbuzz' ausgeben.
# Lösung: Fälle nacheinander prüfen und nur einen nachfolgenden Fall prüfen, falls der vorherige nicht 'True' ergeben hat (if-elif-else Konstruktionen)
'''    
def fizzbuzz():
    for i in range(30):
        # '==' muss als Vergleichsoperator verwendet werden
        if i % 3 = 0:
            # fizz soll ein String sein, Anführungsstriche fehlen
            print "Ausgabe: " + fizz
        if i%5 == 0:
            print "Ausgabe: " + 'buzz'
        # In Python muss für das logische 'und' 'and' verwendet werden, nicht '&&'
        if i%5 == 0 && i%3 == 0:
            print "Ausgabe: " + 'fizzbuzz'
        else:
            # Integer kann nicht mit String konkateniert werden. Davor ist ein Cast des Integers zu String nötig.
            print "Ausgabe: " + i

fizzbuzz()            
'''
# Muster:
'''
def fizzbuzz():
    for i in range(30):
        if i%5 == 0 and i%3 == 0:
            print "Ausgabe: " + 'fizzbuzz'
        elif i%5 == 0:
            print "Ausgabe: " + 'buzz'
        elif i%3 == 0:
            print "Ausgabe: " + 'fizz'
        else:
            print "Ausgabe: " + str(i)

fizzbuzz()
'''

            

        
   


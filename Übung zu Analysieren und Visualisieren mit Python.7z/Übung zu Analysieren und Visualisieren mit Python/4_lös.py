# -*- coding: utf-8 -*-
import codecs
import string
import collections
import matplotlib.pyplot as plt

# Laden der Stoppwortliste als Set.
# Quelle: https://algs4.cs.princeton.edu/35applications/stopwords.txt
default_stop_words = set(codecs.open("stopwords.txt", encoding="utf-8").read().split())

# Laden des Textes.
# Alle Weihnachtsgeschichten sind von gutenberg.org unter der Full Project Gutenberg-tm Lizenz.
christmas_carol = codecs.open("christmas_carol.txt", encoding="utf-8").read()
print len(default_stop_words)
# 4a)
def remove_punctuation(text):
    for char in string.punctuation:
        text = text.replace(char, "")
    return text

# 4b)    
def remove_stop_words(words, stop = default_stop_words):
    pruned_word_list = []
    for word in words:
        if word not in stop:
            pruned_word_list.append(word)
    return pruned_word_list
    
def remove_stop_words_fallback(a, b = default_stop_words):
    a = filter(lambda a_: a_ not in b, a)
    return a

# 4c)    
def prepare_text_for_analysis(text, stop = default_stop_words):
    
    text = remove_punctuation(text.lower())
    print len(text.split())
    text = remove_stop_words(text.split())
    
    #text = remove_stop_words_fallback(text.split())
    return text

# 4d) & 4e)
def plot_word_frequencies(prepared_text):

    # 4d)
    freqs = collections.Counter(prepared_text)
    carol = freqs.most_common(10)
    print carol
    # 4e)
    x = []
    y = []
    # Da carol eine Liste von Tupeln ist, bekommt man für jedes Element aus carol gleichzeitig x und y Werte für den Graphen.
    for tuple in carol:
        x.append(tuple[0])
        y.append(tuple[1])
        
    # Alternativ:
    # x, y = zip(*carol)
    # * "entpackt" das übergebene Iterable in seine Bestandteile. Hier wird die Liste aus Tupeln in die Tupel zerlegt.
    # zip erstellt aus übergebenen Iterables eine Liste von Tupeln. Dabei werden die ersten Elemente aller Iterables in ein Tupel gepackt, alle zweiten in ein anderes usw.
    # Somit erhalten wir eine Liste mit zwei Tupeln: Im ersten Tupel sind die Wörter, im zweiten die Häufigkeiten.
    # Folgendes passiert also:
    # carol:
    # [(u'i', 329), (u'scrooge', 314), (u'ghost', 89),...]
    #
    # *carol:
    # (u'i', 329), (u'scrooge', 314), (u'ghost', 89),... werden zip() einzeln übergebenen
    #
    # zip(*carol):
    # [(u'i', u'scrooge', u'ghost', ...), (329, 314, 89, ...)]
    

    plt.bar(x, y, color = "green")
    plt.xlabel('Most common words')
    plt.ylabel('Occurences')
    plt.title('Frequency of most common words in Christmas Carol')
    plt.xticks(rotation=45)
    plt.show()

    

plot_word_frequencies(prepare_text_for_analysis(christmas_carol))


# -*- coding: utf-8 -*-
import random

# Aufgabe 3.1 a)
print "Aufgabe 3.1 a)"
beer_count = 99
beer_string = "bottles of beer"
wall_string = "on the wall"

print str(beer_count) + " " + beer_string + " " + wall_string + ", " + str(beer_count) + " " + beer_string + "."

# Aufgabe 3.1 b)
print "\nAufgabe 3.1 b)"
tabbed_string = "\tArbitrarily indenting\n\tthings is\t \tboring\t"
print tabbed_string.split("\t")

# Aufgabe 3.1 c)
print "\nAufgabe 3.1 c)"
name = "Olaf Olafsson"
location = "Yggdrasil"
print name[:3]+location[-3:]
print location+name[4:7]

# Aufgabe 3.2 a)
print "\nAufgabe 3.2 a)"
long_list = [213, 12.34, wall_string, 32, 876, 27, beer_count, 3.0, "Zahl", "*", 72, 101, "leer", beer_string]
print long_list[0]
print long_list[-3]
print long_list[-1]



# Aufgabe 3.2 b)
print "\nAufgabe 3.2 b)"
print long_list[:len(long_list)/2]
print long_list[::2]

# Aufgabe 3.2 c)
print "\nAufgabe 3.2 c)"
base_list = ["Text", 3, "alt"]
base_list_kopie = base_list[:]
additional_list = ["neue", 2, ["Elemente", 1, 0]]

# mit extend
base_list.extend(additional_list[:-1])
base_list.extend(additional_list[-1])
print "Erweiterte Liste mit list.extend(): {}".format(base_list)


# mit + Operator
print "Erweiterte Liste mit + Operator: {}".format(base_list_kopie+additional_list[:2]+additional_list[2])

# Aufgabe 3.3 a)
print "\nAufgabe 3.3 a)"
num = raw_input("Zahl eingeben: ")
if int(num)%7 == 0:
    print "teilbar"
else:
    print "nicht teilbar"

# Aufgabe 3.3 b)
print "\nAufgabe 3.3 b)"
def want_to_talk(is_drunk, has_bad_vibe):
    if has_bad_vibe != is_drunk:
        print "maybe"
    elif is_drunk and has_bad_vibe:
        print "nope"
    else:
        print "sure"

# Sollte "nope" ausgeben
want_to_talk(True, True)
# Sollte "maybe" ausgeben
want_to_talk(True, False)
# Sollte "maybe" ausgeben
want_to_talk(False, True)
# Sollte "sure" ausgeben
want_to_talk(False, False)            
    
# Aufgabe 3.4 a)
print "\nAufgabe 3.4 a)"
num = 0
while num != 6:
    num = random.randint(1,6)
    print num

# Aufgabe 3.4 b)
print "\nAufgabe 3.4 b)"
bad_word = "schlecht"
list_to_sanitize = ["schlecht", "schlecht", "gut", "was", "klar", 3.4, "3.4b)", "schlecht", "muster", "schlecht", "", "schlecht"]


while bad_word in list_to_sanitize:
    list_to_sanitize.remove(bad_word)
    

print list_to_sanitize

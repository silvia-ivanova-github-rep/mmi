def fizzbuzz_nested(x):
    if x % 3 == 0:
        if x %5 == 0:
            print 'fizzbuzz'
        else:
            print 'fizz'
    elif x % 5 == 0:
        print 'buzz'
    else:
        print x
            
def fizzbuzz_with_boolean(x):
    if x % 3 == 0 and x %5 == 0:
        print 'fizzbuzz'
    elif x % 3 == 0:
        print 'fizz'
    elif x % 5 == 0:
        print 'buzz'
    else:
        print x
            
def fizzbuzz_concatenating(x):
    result = []
    if x % 3 == 0:
        result.append('fizz')
    if x %5 == 0:
        result.append('buzz')
    if len(result) > 0:
        print ''.join(result)
    else:
        print x
            
for x in range(1, 30):
    fizzbuzz_nested(x)
    fizzbuzz_with_boolean(x)
    fizzbuzz_concatenating(x)
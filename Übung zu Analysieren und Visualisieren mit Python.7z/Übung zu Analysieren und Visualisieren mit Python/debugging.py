import pdb

# In jeder der Methoden sind Fehler, die entweder zu falschem Verhalten oder zu einer Fehlermeldung führen.
# Entfernt die Kommentare für die Methode und ihren Aufruf, die ihr untersuchen wollt.
# Packt gerade nicht zu untersuchende Methoden wieder in Kommentare, damit ihr nur die Fehler der aktuellen Methode beachten müsst.

'''   
def check_if_letter_is_c(text):
    if (text = 'c'):
        return True
    else:
        return false
        
check_if_letter_is_c('a')
'''

'''       
def calculate_average(number_list):
    avg = 0
    for number in number_list:
        avg += number
    return avg/len(number_list)
    
calculate_average([1,2,3,4,5])
'''

'''
def append_to_list(liste=[], element):
    liste.append(element)
    return liste
    
append_to_list()
append_to_list()
append_to_list()
'''

'''
def remove_from_list(liste, element):
    for el in liste:
        if el == element:
            liste.remove(element)

elements = ["test", "test", "kein_test", "kein_test", "kein_test", "kein_test", "kein_test", "test", "kein_test", "kein_test", "test"]
remove_from_list([], 'test')
'''
'''        
def open_file():
    with open(filepath, 'w') as f:
        print f.read()
        
open_file()
'''

'''    
def normalize_text(text):
    text = 5
    text.low()
    for punct in string.punctuation:
        text.replace(punct, 0)
    return text
    
normalize_text('ojaosdolqa:;ad,q12,asd..!)
'''

'''
def calculate_value(a, b):
    result = 0
    resuit = a+b*10
    return result
    
calculate_value(1,2)
'''

'''    
def fizzbuzz():
    for i in range(30):
        if i % 3 = 0:
            print "Ausgabe: " + fizz
        if i%5 == 0:
            print "Ausgabe: " + 'buzz'
        if i%5 == 0 && i%3 == 0:
            print "Ausgabe: " + 'fizzbuzz'
        else:
            print "Ausgabe: " + i

fizzbuzz()            
'''

            

        
   

